import generateMarkdown from "@/markdown-generator";
import path from "path";
import { chromium } from "playwright";
import fs from "fs";
export default async function crawlWebsite(url: string, outputPath: string): Promise<void> {
  let browser = null;
  try {
    console.log(`Starting crawl for ${url}`);

    // Retry mechanism for browser launch with exponential backoff
    let retries = 3;
    while (retries > 0) {
      try {
        browser = await chromium.launch({ headless: true });
        console.log('Browser launched successfully.');
        break; // Exit the loop if successful
      } catch (error) {
        retries--;
        console.error(`Browser launch attempt failed: ${(error as any).message}`);
        if (retries === 0) throw error;
        const delay = Math.pow(2, 3 - retries) * 1000; // Exponential backoff
        console.log(`Retrying browser launch in ${delay}ms... (${3 - retries}/3 attempts remaining)`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    if (!browser) {
      throw new Error('Failed to launch browser.');
    }

    const page = await browser.newPage();
    console.log('New page created.');

    // Set a custom User-Agent to mimic a real browser
    await page.setExtraHTTPHeaders({
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    });

    // Retry mechanism for navigation with exponential backoff
    retries = 3;
    while (retries > 0) {
      try {
        await page.goto(url, { waitUntil: 'networkidle', timeout: 60000 });
        console.log(`Successfully navigated to ${url}`);
        break; // Exit the loop if successful
      } catch (error) {
        retries--;
        console.error(`Navigation to ${url} failed: ${(error as any).message}`);
        if (retries === 0) throw error;
        const delay = Math.pow(2, 3 - retries) * 1000; // Exponential backoff
        console.log(`Retrying ${url} in ${delay}ms... (${3 - retries}/3 attempts remaining)`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    // Simulate scrolling to trigger dynamic content loading
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(2000); // Wait for dynamic content to load

    // Wait for critical content using waitForFunction
    try {
      await page.waitForFunction(
        () => {
          const mainContent = document.querySelector('main');
          return mainContent && mainContent.innerText.length > 0;
        },
        { timeout: 30000 } // Reduced timeout
      );
      console.log('Critical content loaded successfully.');
    } catch (error) {
      console.error(`Failed to load critical content on ${url}:`, (error as any).message);
      throw new Error('Critical content not found.');
    }

    // Extract title and content, then convert to Markdown
    const title = await page.title();
    const content = await page.content();
    if (!content || content.trim().length === 0) {
      console.warn(`Skipping ${url} due to missing content.`);
      return;
    }

    const markdown = generateMarkdown(title, content);

    // Save Markdown file
    const filePath = path.join(outputPath, `${title.replace(/[^a-z0-9]/gi, '_')}.md`);
    fs.mkdirSync(outputPath, { recursive: true });
    fs.writeFileSync(filePath, markdown);
    console.log(`Markdown saved to ${filePath}`);
  } catch (error) {
    console.error(`Error crawling ${url}:`, (error as any).message);
  } finally {
    if (browser) {
      await browser.close(); // Ensure browser is closed to free resources
      console.log('Browser closed after crawling.');
    }
  }
}